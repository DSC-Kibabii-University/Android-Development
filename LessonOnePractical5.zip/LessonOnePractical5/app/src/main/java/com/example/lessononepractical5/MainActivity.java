package com.example.lessononepractical5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
 Button increment, decrement, order;
 EditText name;
 CheckBox cream, chocolate;
 int quantity =1;
 TextView coffee_quantity;
 Intent intent = null, chooser= null;
 String myName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        increment = findViewById(R.id.addition);
        decrement = findViewById(R.id.minus);
        order = findViewById(R.id.order);
        name = findViewById(R.id.name);
        coffee_quantity= findViewById(R.id.quanity);
        cream = findViewById(R.id.cream);
        chocolate = findViewById(R.id.chocolate);
        quantity = Integer.parseInt(coffee_quantity.getText().toString());

    }

    // Check box cream and chocolate




    public void  minus(View view) {


        quantity = Integer.parseInt(coffee_quantity.getText().toString());
        if (quantity<=0) {
            Toast.makeText(getApplicationContext(), "You cannnot order less that One Coffee", Toast.LENGTH_LONG).show();
        }
        else {
            quantity = quantity - 1;
            String red = String.valueOf(quantity);
            coffee_quantity.setText(red);
        }
    }
    public void addition(View view) {
        quantity = Integer.parseInt(coffee_quantity.getText().toString());
        if (quantity>=10) {
            Toast.makeText(getApplicationContext(), "You cannnot order more that One Coffee", Toast.LENGTH_LONG).show();

        }
        else {

            quantity = quantity + 1;
            String red = String.valueOf(quantity);
            coffee_quantity.setText(red);
        }

    }
    public void order(View view) {
        myName= name.getText().toString();
        checkboxex();


        }
     public void checkboxex (){

         if (cream.isChecked() && chocolate.isChecked()) {
             billing(30,"cream and Chocolate" );
         }else
         if (chocolate.isChecked()) {
            billing(10, "chocolate");
         } else
         if (cream.isChecked() ){

            billing(20,"cream");
     }
         else {
             billing(0,"No Topping" );
         }



    }

    public void billing(int topping_price, String topping){
        int price = 15;
        int coffee_price = quantity*price;
        int total_price = coffee_price+topping_price;
        String order = myName+ " you have ordered " +quantity+" coffee @ price: "+coffee_price+"\n"+ topping  + " @ price: " + topping_price + "\n\nTotal Price: "+ total_price;

        //intnet
        open_email(order);

    }

    public void open_email (String order) {

        String[] cars = {"prestone@kibu.ac.ke"};
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setType("*/*");
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL, cars);
        intent.putExtra(Intent.EXTRA_SUBJECT, "Coffee Order");
        intent.putExtra(Intent.EXTRA_TEXT, order);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }

    }




}